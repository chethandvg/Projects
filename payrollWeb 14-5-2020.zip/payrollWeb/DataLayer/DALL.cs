﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public interface IDbComponent
    {
        bool Addemp(string name, string addr,string emailId, string userName, string pswd,string status);
        void Editemp(int id, string name, string addr,string emailId);
        void Addsal(decimal ESI, decimal PF, decimal Others, int month, int year, int id, decimal Gross);
        List<emp> GetAllEmp();
        List<empsal> GetAllSal(int id);
        List<empsal> GetSalbyMonth(int id, int mon);
        List<empsal> GetSalbyYear(int id,int mnth, int year);
        emp FindEmp(int Empid);
        emp FindLogin(int Loginid);
        emp FindLogin(string LoginName);
        emp FindEmp(string name);
        bool FindLogin(string name,string pswd,string status);

    }
    class Dlayer : IDbComponent
    {
        static ConsoleEntities enn = new ConsoleEntities();
        
        public bool Addemp(string name, string addr,string emailId, string userName, string pswd,string status)
        {
            try
            {
                CreateLogin(userName, pswd, status);
                int id = enn.Logins.FirstOrDefault((c) => c.uname == userName).loginId;
                emp Emp = new emp { empname = name, empaddress = addr, loginId_frnkey = id, empid = 1,email=emailId};
                enn.emps.Add(Emp);
                enn.SaveChanges();
                return true;
            }
            catch (Exception)
            {

                return false;
            }

        }

        private void CreateLogin(string userName, string password, string status)
        {
            Login login = new Login { uname = userName, pswd = password,loginId=1,role=status };
            enn.Logins.Add(login);
            enn.SaveChanges();

        }

        public void Addsal(decimal ESI, decimal PF, decimal Others, int month, int year, int id, decimal Gross)
        {
            empsal sal = new empsal { payid = 1, empid_frnkey = id, esi = ESI, pf = PF, others = Others, mnth = month, yr = year,gross=Gross };
            enn.empsals.Add(sal);
            enn.SaveChanges();
        }

        public void Editemp(int id, string name, string addr,string emailId)
        {
            emp Emp = enn.emps.FirstOrDefault((c) => c.empid == id);
            Emp.empname = name;
            Emp.empaddress = addr;
            Emp.email = emailId;
            enn.SaveChanges();
        }

        public emp FindLogin(int Loginid)
        {
            emp Emp = enn.emps.FirstOrDefault((c) => c.loginId_frnkey == Loginid);
            return Emp;
        }

        public List<emp> GetAllEmp()
        {
            return new ConsoleEntities().emps.ToList();
        }

        public List<empsal> GetAllSal(int Empid)
        {
            
            List<empsal> unFiltered= enn.empsals.ToList();
            List<empsal> filtered = new List<empsal>();
            foreach (var item in unFiltered)
            {
                if (item.empid_frnkey==Empid)
                {
                    filtered.Add(item);
                }
            }
            return filtered;
        }

        public List<empsal> GetSalbyMonth(int Empid, int mon)
        {
            List<empsal> oldSal = GetAllSal(Empid);
            List<empsal> newSal = new List<empsal>();
            foreach (var item in oldSal)
            {
                if (item.mnth==mon)
                {
                    newSal.Add(item);
                }
            }
            return newSal;
        }

        public List<empsal> GetSalbyYear(int Empid,int mnth, int year)
        {
            List<empsal> oldSal = GetAllSal(Empid);
            List<empsal> newSal = new List<empsal>();
            foreach (var item in oldSal)
            {
                if (item.yr == year&&item.mnth==mnth)
                {
                    newSal.Add(item);
                }
            }
            return newSal;
        }

        public emp FindEmp(string name)
        {
            emp Emp = enn.emps.FirstOrDefault((c) => c.empname == name);
            return Emp;
        }

        public bool FindLogin(string name,string pswd,string status)
        {

            Login log = enn.Logins.FirstOrDefault((c) => c.uname == name&&c.pswd==pswd&&(c.role==status||c.role=="admin"));
            if (log!=null)
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }

        public emp FindEmp(int Empid)
        {
            emp found = enn.emps.FirstOrDefault((c) => c.empid == Empid);
            return found;
        }

        public emp FindLogin(string LoginName)
        {
            Login log = enn.Logins.FirstOrDefault((c) => c.uname == LoginName);
            return enn.emps.FirstOrDefault((c) => c.loginId_frnkey == log.loginId);
            
        }
    }
    public class DataFactory
    {
        public static IDbComponent GetComp()
        {
            return new Dlayer();
        }
    }
}
