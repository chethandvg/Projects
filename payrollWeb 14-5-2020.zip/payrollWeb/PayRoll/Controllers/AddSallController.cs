﻿using DataLayer;
using PayRoll.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PayRoll.Controllers
{
    public class AddSallController : ApiController
    {
        static IDbComponent data = DataFactory.GetComp();
        [HttpPost]
        public bool Addsal(Empsal sal)
        {
            try
            {
                data.Addsal(sal.esi,
                    sal.pf,
                    sal.others,
                    sal.mnth,
                    sal.yr, 
                    sal.empid,
                    sal.gross);
                return true;
            }
            catch (Exception)
            {
               // Console.WriteLine(ex);
                return false;
            }

        }
    }
}
