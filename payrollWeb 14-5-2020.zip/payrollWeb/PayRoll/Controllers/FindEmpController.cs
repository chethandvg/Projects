﻿using DataLayer;
using PayRoll.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PayRoll.Controllers
{
    
    public class FindEmpController : ApiController
    {
        static IDbComponent data = DataFactory.GetComp();
        public List<Emp> GetAllEmp()
        {
            var dt = data.GetAllEmp();
            var empList = dt.Select((e) => new Emp
            {
                empid = e.empid,
                loginId = e.loginId_frnkey.GetValueOrDefault(),
                empaddress = e.empaddress,
                empname = e.empname,
                emailId=e.email
            }).ToList();
            return empList;
        }
        [HttpGet]
        public Emp FindEmployee(string EmpId)
        {
            int id = int.Parse(EmpId);
            var emp = data.FindEmp(id);
            var found = new Emp
            {
                empid = emp.empid,
                loginId = emp.loginId_frnkey.GetValueOrDefault(),
                empaddress = emp.empaddress,
                empname = emp.empname,
                emailId=emp.email
            };
            return found;
        }
        

    }
}
