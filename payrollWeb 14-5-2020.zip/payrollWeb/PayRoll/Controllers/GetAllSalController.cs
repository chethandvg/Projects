﻿using DataLayer;
using PayRoll.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PayRoll.Controllers
{
    public class GetAllSalController : ApiController
    {
        static IDbComponent data = DataFactory.GetComp();
        public List<Empsal> GetAllSal(string Empid)
        {
            // Emp em = new FindEmpController().FindEmployee(Empid.ToString());
            var dt = data.GetAllSal(int.Parse(Empid));
            if (dt.Count == 0)
            {
                return null;
            }
            List<Empsal> salList = convert(dt);

            return salList;
        }

        private static List<Empsal> convert(List<empsal> dt)
        {
            return dt.Select((e) => new Empsal
            {
                empid = e.empid_frnkey.GetValueOrDefault(),
                payid = e.payid,
                esi = e.esi.GetValueOrDefault(),
                pf = e.pf.GetValueOrDefault(),
                others = e.others.GetValueOrDefault(),
                mnth = e.mnth.GetValueOrDefault(),
                yr = e.yr.GetValueOrDefault(),
                gross = e.gross.GetValueOrDefault(),
                net = e.gross.GetValueOrDefault() - e.pf.GetValueOrDefault() - e.others.GetValueOrDefault() - e.esi.GetValueOrDefault()
            }).ToList();
        }
        [HttpGet]
        public List<Empsal> GetSalByDate(string EmpId,string mnth,string yr)
        {
            //var salbymnth =convert( data.GetSalbyMonth(int.Parse(EmpId), int.Parse(mnth)));
             return convert( data.GetSalbyYear(int.Parse(EmpId),int.Parse(mnth), int.Parse(yr)));
            //List<Empsal> newlist = new List<Empsal>();
            //foreach (var item in salbymnth)
            //{
            //    if (item.yr==int.Parse(yr))
            //    {
            //        newlist.Add(item);
            //    }
            //}
            //foreach (var item in salbyyr)
            //{
            //    if (item.mnth==int.Parse(mnth))
            //    {
            //        newlist.Add(item);
            //    }
            //}
            
        }
    }
}
