﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PayRoll.Models
{
    public class Emp
    {
        public int empid { get; set; }
        public string empname { get; set; }
        public string empaddress { get; set; }
        public string emailId { get; set; }
        public int loginId { get; set; }
    }
    public class Empsal
    {
        public int empid { get; set; }
        public int payid { get; set; }
        public decimal esi { get; set; }
        public decimal pf { get; set; }
        public decimal others { get; set; }
        public int mnth { get; set; }
        public int yr { get; set; }
        public decimal gross { get; set; }
        public decimal net { get; set; }
    }
    public class Logins
    {
        public int loginid { get; set; }
        public string uname { get; set; }
        public string pswd { get; set; }
        public string status { get; set; }
    }
    public class emplogin
    {
        public Emp empdata { get; set; }
        public Logins logindata { get; set; }     
    }
}