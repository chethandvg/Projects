﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PrentUi
{
    public partial class EmpRequest : System.Web.UI.Page
    {
        string uname { get; set; }
        string status { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["name"] != null)
            {
                uname = Session["name"].ToString();
                // status = Session["status"].ToString();
                head.Text = uname;
            }
            else
                Response.Redirect("PerfectLogin.aspx");
        }

        public void SendMail()
        {
            
        }
        protected void Send_mail(object sender, EventArgs e)
        {
            try
            {
                MailMessage mail = new MailMessage();
                mail.To.Add("chethandvg3@gmail.com");
                mail.From = new MailAddress("chethandvg3@gmail.com");
                mail.Subject = txtSubject.Text + "From:" + uname;
                string Body = txtMsg.Text;
                mail.Body = Body;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                smtp.Port = 587;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential("chethandvg3@gmail.com", "venky123*");

                //Or your Smtp Email ID and Password
                smtp.EnableSsl = true;
                smtp.Send(mail);
                string message = "Requested successfully";
                Alert_Message(message);
               // Response.Redirect("EmpPage1.aspx");
            }
            catch (SmtpException ex)
            {

                string message = "Request Unsuccessfull " + ex.Message;
                Alert_Message(message);
            }
            
        }

        private void Alert_Message(string message)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("<script type = 'text/javascript'>");
            sb.Append("window.onload=function(){");
            sb.Append("alert('");
            sb.Append(message);
            sb.Append("')};");
            sb.Append("</script>");
            ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("EmpPage1.aspx");
        }
        protected void btnOut_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("PerfectLogin.aspx");
        }
    }
}