﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PrentUi
{
    public partial class UI : System.Web.UI.Page
    {
         string uname { get; set; }
        string status { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["name"] != null)
            {
                if (Session["status"].ToString() == "admin")
                {
                    uname = Session["name"].ToString();
                    status = Session["status"].ToString();
                    head.Text = "Wellcome " + uname;
                }
                else
                    Response.Redirect("PerfectLogin.aspx");
            }
            else
            {
                Response.Redirect("PerfectLogin.aspx");
            }

        }

        protected void btnOut_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("PerfectLogin.aspx");
        }
    }
}