﻿using PayRoll.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PrentUi
{
    public partial class EmpPage1 : System.Web.UI.Page
    {
        string uname { get; set; }
        string status { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["name"] != null)
            {
                uname = Session["name"].ToString();
                // status = Session["status"].ToString();
                username.Text =head.Text= uname;
            }
            else
                Response.Redirect("PerfectLogin.aspx");

            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:1150/api/FindLogin?name=" + uname);
            var consumeapi = hc.GetAsync("FindLogin?Logname=" + uname);
            consumeapi.Wait();
            var readdata = consumeapi.Result;
            if (readdata.IsSuccessStatusCode)
            {
                var task = readdata.Content.ReadAsAsync<Emp>();
                task.Wait();
                var result = task.Result;
                empName.Text = result.empname;
                empId.Text = result.empid.ToString();
                empAddr.Text = result.empaddress;
                empEmail.Text = result.emailId;
            }
        }

        protected void btnOut_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("PerfectLogin.aspx");
        }

        protected void request_Click(object sender, EventArgs e)
        {
            Response.Redirect("EmpRequest.aspx");
        }
    }
}