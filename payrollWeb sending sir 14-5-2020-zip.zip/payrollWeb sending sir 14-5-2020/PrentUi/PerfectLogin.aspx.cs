﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Routing;
using System.Web.Services.Protocols;
using System.Web.UI;
using System.Web.UI.WebControls;
using PayRoll.Controllers;
using PayRoll.Models;

namespace PrentUi
{
    public partial class PerfectLogin : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string role;
            if (chkAdmin.Checked)
            {
                role = "admin";
                loginpage(role, "AdminLogin1.aspx");
            }
            else
            {
                role = "employee";
                loginpage(role, "EmpPage1.aspx");
            }
        }

        private void loginpage(string role,string url)
        {
            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:1150/api/");
            var consumeapi = hc.GetAsync("FindLogin?name=" + txtusername.Text + "&pswd=" + txtpass.Text + "&status=" + role);
            consumeapi.Wait();
            var readdata = consumeapi.Result;
            if (readdata.IsSuccessStatusCode)
            {
                var task = readdata.Content.ReadAsAsync<bool>();
                task.Wait();
                var result = task.Result;
                //string message = result.ToString();
                //System.Text.StringBuilder sb = new System.Text.StringBuilder();
                //sb.Append("<script type = 'text/javascript'>");
                //sb.Append("window.onload=function(){");
                //sb.Append("alert('");
                //sb.Append(message);
                //sb.Append("')};");
                //sb.Append("</script>");
                //ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
                if (result)
                {
                    Session["name"] = txtusername.Text;

                    Session["status"] = role;

                    Response.Redirect(url);
                }
                else
                {
                    string message = "Login Credentials does not match";
                    System.Text.StringBuilder sb = new System.Text.StringBuilder();
                    sb.Append("<script type = 'text/javascript'>");
                    sb.Append("window.onload=function(){");
                    sb.Append("alert('");
                    sb.Append(message);
                    sb.Append("')};");
                    sb.Append("</script>");
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
                    //Response.Write("data not match");
                }
            }
        }

        //protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        //{
        //    HttpClient hc = new HttpClient();
        //    hc.BaseAddress = new Uri("http://localhost:1150/api/");
        //    var consumeapi = hc.GetAsync("FindLogin?name=" + txtusername.Text + "&pswd=" + txtpass.Text);
        //    consumeapi.Wait();
        //    var readdata = consumeapi.Result;
        //    if (readdata.IsSuccessStatusCode)
        //    {
        //        var task = readdata.Content.ReadAsAsync<bool>();
        //        task.Wait();
        //        var result = task.Result;
        //        if (result)
        //        {
        //            args.IsValid = true;

        //        }
        //        else
        //            args.IsValid = false;
        //    }
        //}
    }
}