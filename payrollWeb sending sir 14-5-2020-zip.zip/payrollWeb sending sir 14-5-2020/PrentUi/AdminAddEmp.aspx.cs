﻿using PayRoll.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace PrentUi
{
    public partial class AdminLogin2 : System.Web.UI.Page
    {
        string uname { get; set; }
        string status { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["status"] != null)
            {
                if (Session["status"].ToString() == "admin")
                {
                    uname = Session["name"].ToString();
                    status = Session["status"].ToString();
                }
                else
                    Response.Redirect("PerfectLogin.aspx");
            }
            else
                Response.Redirect("PerfectLogin.aspx");
            //hid.Value = "employee";
        }

        protected void btnOut_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("PerfectLogin.aspx");
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminLogin1.aspx");
        }

        //protected void btnAdd_Click(object sender, EventArgs e)
        //{
        //    string role;
        //    if (chkAdmin.Checked)
        //    {
        //        role = "admin";
        //    }
        //    else role = "employee";

        //    HttpClient hc = new HttpClient();
        //    hc.BaseAddress = new Uri("http://localhost:1150/api/");
        //    Emp empdata = new Emp();
        //    empdata.empname = txtname.Text;
        //    empdata.empaddress = txtAddress.Text;
        //    empdata.empid = 1;
        //    Logins logdata = new Logins();
        //    logdata.loginid = 1;
        //    logdata.uname = txtUname.Text;
        //    logdata.pswd = txtPass.Text;
        //    if (chkAdmin.Checked)
        //    {
        //        logdata.status = "admin";
        //    }
        //    else
        //    {
        //        logdata.status = "employee";
        //    }

        //    var consumeapi = hc.GetAsync("AddEmp?empdata="+empdata+"&logdata="+logdata);
        //    consumeapi.Wait();
        //    var readdata = consumeapi.Result;
        //    if (readdata.IsSuccessStatusCode)
        //    {
        //        var task = readdata.Content.ReadAsAsync<bool>();
        //        task.Wait();
        //        var result = task.Result;
        //        if (result)
        //        {
        //            string message = "Inserted successfully";
        //            System.Text.StringBuilder sb = new System.Text.StringBuilder();
        //            sb.Append("<script type = 'text/javascript'>");
        //            sb.Append("window.onload=function(){");
        //            sb.Append("alert('");
        //            sb.Append(message);
        //            sb.Append("')};");
        //            sb.Append("</script>");
        //            ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
        //        }
        //    }
        //}

        //protected void hidden_load(object sender, EventArgs e)
        //{
        //    if (chkAdmin.Checked)
        //    {
        //        hid.Value = "admin";
        //    }
        //    else
        //    {
        //        hid.Value = "employee";
        //    }
        //}
    }
}