﻿using DataLayer;
using PayRoll.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PayRoll.Controllers
{
    public class FindLoginController : ApiController
    {
        static IDbComponent data = DataFactory.GetComp();
        [HttpGet]
        public bool FindLogin(string name,string pswd,string status)
        {
            var e = data.FindLogin(name,pswd,status);           
            return e;
        }
        [HttpGet]
        public Emp FindEmployee(string Logname)
        {
            var emp = data.FindLogin(Logname);

            var found = new Emp
            {
                empid = emp.empid,
                loginId = emp.loginId_frnkey.GetValueOrDefault(),
                empaddress = emp.empaddress,
                empname = emp.empname,
                emailId=emp.email
            };
            return found;
        }
    }
}
