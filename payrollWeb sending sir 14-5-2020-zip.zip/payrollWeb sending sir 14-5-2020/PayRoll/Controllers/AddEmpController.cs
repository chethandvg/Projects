﻿using DataLayer;
using Newtonsoft.Json;
using PayRoll.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PayRoll.Controllers
{
    public class AddEmpController : ApiController
    {
        static IDbComponent data = DataFactory.GetComp();
        [HttpPost]
        public bool Addemp(emplogin el)
        {
            Emp e = el.empdata;
            Logins log = el.logindata;
            try
            {
                bool state= data.Addemp(e.empname, e.empaddress,e.emailId, log.uname, log.pswd,log.status);
                return state;
            }
            catch (Exception)
            {
                //Console.WriteLine(ex);
                return false;
            }

        }
        
    }
}
