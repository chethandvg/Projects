﻿using DataLayer;
using PayRoll.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PayRoll.Controllers
{
    public class EditEmpController : ApiController
    {
        static IDbComponent data = DataFactory.GetComp();
        [HttpPost]
        public bool Editemp(Emp e)
        {
            try
            {
                data.Editemp(e.empid, e.empname, e.empaddress,e.emailId);
                return true;
            }
            catch (Exception)
            {
                //Console.WriteLine(ex);
                return false;
            }
        }
    }
}
